package com.example.taskroshn20232mca0028;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
public class Dbhandlers extends SQLiteOpenHelper {
	public Dbhandlers(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
		super(context, name, factory, version);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
	db.execSQL("create table Employee(name varchar(15),num varchar(15),leave varchar(15),date varchr(15))");
	}



	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}
	public void  insertdb(String name,String num,String leave,String date){
		SQLiteDatabase db=this.getWritableDatabase();
		db.execSQL("insert into Employee values(?,?,?,?)",new String[]{name,num,leave,date});
		db.close();
	}
	public String  Dispdate(String d){
		String id="";
		SQLiteDatabase db=this.getReadableDatabase();
		Cursor cr=db.rawQuery("select name from Employee where date=?",new String[]{d});
		while(cr.moveToNext()){
			String i=cr.getString(0);
			id+=i+"\n";

		}
		db.close();
		return id;
	}

	public String  Dispday(String day){
		String tid="";
		SQLiteDatabase db=this.getReadableDatabase();
		Cursor cr=db.rawQuery("select num from Employee where num>=2",new String[]{day});
        while(cr.moveToNext()){
			String i=cr.getString(0);
			String j=cr.getString(1);
			String k=cr.getString(0);
			String l=cr.getString(1);
			tid+=i+"\t"+j+"\t"+k+"\t"+l+"\t";

		}
		db.close();
		return tid;
	}
}
