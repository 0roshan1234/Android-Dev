package com.example.taskroshn20232mca0028;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
EditText name,num;
Spinner spins;

Button apply,datebtn,daysbtn;
ImageView imgs;
Dbhandlers db;
String leave[]={"casual leave","plannedleave"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		name=findViewById(R.id.namebox);
		num=findViewById(R.id.numbox);
		spins=findViewById(R.id.spinner);
		apply=findViewById(R.id.button);
		datebtn=findViewById(R.id.button2);
		daysbtn=findViewById(R.id.button3);
		ArrayAdapter adapter=new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,leave);
		spins.setAdapter(adapter);
        spins.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				String holiday=parent.getItemAtPosition(position).toString();

			}
		});
		apply.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
			}
		});

	}
}